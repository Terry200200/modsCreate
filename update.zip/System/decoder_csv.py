import sys
from lib_csv import decode_file

decode_file(sys.argv[1])
