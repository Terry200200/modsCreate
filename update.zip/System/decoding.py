import os

try:
	from sc_compression.compression import Decompressor, Compressor
except ImportError:
	from sc_compression.compression import Decompressor, Compressor

if not os.path.exists('in'):
	os.mkdir('in')

if not os.path.exists('out'):
	os.mkdir('out')


for filename in os.listdir('in'):
	with open(f'in/{filename}', 'rb') as fh:
		filedata = fh.read()
		fh.close()
	decompressor = Decompressor()
	decompressed = decompressor.decompress(filedata)
	with open(f'out/{filename}', 'wb') as fh:
		fh.write(decompressed)
		fh.close()
