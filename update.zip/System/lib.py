import os, urllib
from pathlib import Path

version = "Encryptor 2.0\n"

menu = (f"{version}1) Закодировать csv : Закодирует csv (In-Decompressed)\n2) Разкодировать csv : Разкодирует шифрованные csv (In-Compressed)\n\n3) Очистить рабочие папки : Очищает папки\n4) Скачать обновление : Скачивает обновление с сервера\n5) Новости : Новости и обновления скрипта\n---> ")

news = (f"{version}1) На момент 2.0 версии ни какой другой шифроватор не сможет\nрасшифровать csv зашифрованное этим шифроватором\n0) выход\n---> ")

def Clear():
	os.system('clear')
	
def Clean():
		g = input("Вы уверены?\nДа - y\nНет - n\n---> ")
		
		if g == "y":
			[f.unlink() for f in Path("In-Compressed").glob("*") if f.is_file()]
			[f.unlink() for f in Path("In-Decompressed").glob("*") if f.is_file()] 
			[f.unlink() for f in Path("Out-Compressed").glob("*") if f.is_file()] 
			[f.unlink() for f in Path("Out-Decompressed").glob("*") if f.is_file()] 	
			print("[INFO] Готово!")
			exit()
		elif g == "n":
			exit()
	
def checkinternet():
    from urllib import request
    try:
        urllib.request.urlopen('http://google.com')
        
        return True
    except:
        print("[ERROR] Нет доступа к интернету!")
        exit()
        return False
        
def Decod():
	try:
		from sc_compression.compression import Decompressor, Compressor
	except ImportError:
		print("[ERROR] Ошибка!")
		from sc_compression.compression import Decompressor, Compressor
		
	for filename in os.listdir('In-Compressed/'):
		with open(f'In-Compressed/{filename}', 'rb') as fh:
			filedata = fh.read()
			fh.close()
		decompressor = Decompressor()
		decompressed = decompressor.decompress(filedata)
		with open(f'Out-Decompressed/{filename}', 'wb') as fh:
			fh.write(decompressed)
			fh.close()
		print(f"[INFO] Файл: {filename} Разкодирован!")
	
indir = './In-Decompressed/'
outdir = './Out-Compressed/'		
              
def Encod():
	for file in os.listdir(indir):
			if file.endswith('.csv'):
				os.system('python ./System/encoder_csv.py ' + indir+ file)
	
	
def updates():
	import System.updates
	
def exit():
	raise SystemExit
