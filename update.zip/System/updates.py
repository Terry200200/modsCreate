import requests, os, time

def update(file):
    filename = file.split('/')[-1]
    print("[INFO] Скачиваем архив "+ filename)
    r = requests.get(file, allow_redirects=True)
    open(filename, 'wb').write(r.content)
    print("[INFO] Скачан "+ filename)
    print("[TEXT] Распакуйте архив и запустите файл Main.py")
    exit()


file1 = 'https://raw.githubusercontent.com/Terry3030/57446598645753623423232/main/update.zip'

update(file1)