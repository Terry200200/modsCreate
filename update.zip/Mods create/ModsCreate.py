from system.modules.lib import *

def mc():
	while True:
		clear()
		a = input(menu)
		clear()
						
		if a =="1":
			f=input("Выберите пункт\n1) Список хаков с интернетом\n2) Список хаков без интернета\n0) Назад\n---> ")

			clear()
			if f =="1":
				Check.Internet()
				print("Проверка...")
				time.sleep(0.5)
				Check.Update()
				clear()
				hack()
						
			elif f =="2":
				Check.Update(True)
				hack()
						
		elif a =="2":
			clean()
			clear()
						
		elif a =="3":
			Check.Internet()
			updfiles()
			clear()

		elif a =="4":
			update_scrypt()
		elif a =="0":
			return
		mc()
mc()