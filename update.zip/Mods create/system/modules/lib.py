import os
import sys
import json
import urllib
import time
import socket
import subprocess
import csv
import request

from pathlib import Path
from urllib import request
from requests import get
from tqdm import tqdm
from csv import reader, writer

version = "Mods create 1.3.5\n\n"

menu = (f"{version}\033[1;4mОсновное:\033[0m\n1) Список хаков : показывает список хаков\n\n\033[1;4mПрочее:\033[0m\n2) Очистить содержимое папок : очищает содержимое папки csv\n3) Обновить файлы/скачать : обновляет или скачивает файлы бравла для работы скрипта\n4) Скачать обновление скрипта : скачивает обновление скрипта с сервера\n\n---> ")

FILES = ["emotes.csv","messages.csv","player_thumbnails.csv","skins.csv","locations.csv","cards.csv","sprays.csv"]
	
def clear():
	os.system('clear||cls')

def exit():
	raise SystemExit

def updfiles():
	from system.modules.downloader import getfile
	for i in FILES:
		getfile(i)
		
def hack():
	import system.modules.hack
	
def clean():
	c = input("Вы уверены?\nY - Да\nN - Нет\n---> ")

	if c == "Y":
		[f.unlink() for f in Path("csv").glob("*") if f.is_file()] 	
		print("Готово!")
		input("Любая кнопка - меню\n")

	elif c == "N":
		return

def update_scrypt():


class Check:

	@staticmethod			
	def Update(NoInternet = False):
		from system.modules.downloader import downloading, FILES, getfile
		if not NoInternet: downloading()

	@staticmethod
	def Internet():
		for timeout in [1,5,10,15]:
			try:
				socket.setdefaulttimeout(timeout)
				host = socket.gethostbyname("www.google.com")
				s = socket.create_connection((host, 80), 2)
				s.close()
				return True
			except Exception:
				print("Нет подключения к интернету!")
				exit()
				return False
