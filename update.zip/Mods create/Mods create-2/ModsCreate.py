from system.modules.lib import *

def mc():
	while True:
		clear()
		a = input(menu)
		clear()
		
		if a =="1":
			Check.Internet()
			time.sleep(2)
			Check.Update()
			clear()
			hack()
		
		elif a =="2":
			Check.Update(True)
			hack()
		
		elif a =="3":
			clean()
			clear()
		
		elif a =="4":
			Check.Internet()
			updfiles()
			clear()
					
		elif a =="help":
			print(help)
			input("Любая кнопка - назад\n")
			clear()
		elif a =="0":
			return
		mc()
mc()
