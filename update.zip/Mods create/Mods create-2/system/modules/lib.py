import os
import sys
import json
import urllib
import time
import socket
import subprocess
import csv

from pathlib import Path
from urllib import request
from json import loads, load, dump
from requests import get
from tqdm import tqdm
from csv import reader, writer

version = "Mods create 13.0\n\n"

menu = (f"{version}\033[1;4mОсновное:\033[0m\n1) Список хаков\n2) Список хаков без интернета\n\n\033[1;4mПрочее:\033[0m\n3) Очистить содержимое папок\n4) Обновить файлы/скачать\n\nhelp - помощь\n---> ")

help = ("Помощь в скрипте\n\033[1;4mОсновное:\033[0m\n1) Показывает все хаки которые есть в скрипте с интернетом\n2) Показывает все хаки которые есть в скрипте без интернета\n\n\033[1;4mПрочее:\033[0m\n3) Очищает содержимое папки csv\n4) Скачивает обновление файлов с сервера\n")

i = "[INFO] "
	
def clear():
	os.system('clear||cls')

def exit():
	raise SystemExit

def updfiles():
	from system.modules.downloader import getfile, FILES
	for i in FILES:
		getfile(i)
		
def hack():
	import system.modules.hack
	
def clean():
		c = input("Вы уверены?\n1) Да\n2) Нет\n---> ")

		if c == "1":
			[f.unlink() for f in Path("csv").glob("*") if f.is_file()] 	
			print(i+"Готово!")
			input(i+"Любая кнопка - меню\n")

		elif c == "2":
			return

class Check:

	@staticmethod			
	def Update(NoInternet = False):
		from system.modules.downloader import downloading, FILES, getfile
		if not NoInternet: downloading()

	@staticmethod
	def Internet():
		for timeout in [1,5,10,15]:
			try:
				socket.setdefaulttimeout(timeout)
				host = socket.gethostbyname("www.google.com")
				s = socket.create_connection((host, 80), 2)
				s.close()
				return True
			except Exception:
				print(i+"Нет подключения к интернету!")
				exit()
				return False