import os,shutil, sys, json, requests

from System.lib import *

Clear()
                     
def init(ret=True):
    Clear()
    print("[INFO] Скачивание модулей...")
    os.system('pip install sc-compression')
    os.system('pip install colorama')
    os.system('pip install requests')
    Clear()
    config.update({'inited': True})
    json.dump(config, open(cfg_path, 'w'))
    
def Fold(ret=True):
    Clear()
    print("[INFO] Создание папок...")
if not os.path.isdir("In-Compressed"):
    os.mkdir("In-Compressed")
if not os.path.isdir("In-Decompressed"):
    os.mkdir("In-Decompressed")
if not os.path.isdir("Out-Compressed"):
    os.mkdir("Out-Compressed")
if not os.path.isdir("Out-Decompressed"):
    os.mkdir("Out-Decompressed")
    Clear()
    json.dump(config, open(cfg_path, 'w'))

cfg_path = './system/config.json'	
			
if __name__ == '__main__':
    if os.path.isfile(cfg_path):
        try:
            config = json.load(open(cfg_path))
        except:
            config = {'inited': False, 'Folder': True}
    else:
        config = {'inited': False, 'Folder': True}


    if not config['inited']:
        init()
        try: os.system('python%s "%s"' % ('' if isWin else '3', __file__))
        except: pass
      
    if not config['Folder']:
        Fold()
Clear()
	
def Main():
	a = input(menu)
	if a == "1":
		Clear()
		Encod()
		exit()
	elif a == "2":
		Clear()
		Decod()
		exit()
	elif a == "3":
		Clear()
		Clean()
		print("Готово")
		exit()
	elif a == "4":
		Clear()
		checkinternet()
		updates()
	elif a == "5":
		Clear()
		input(news)
		exit()
	else:
		Clear()
		print("Ошибка!")	

	Main()
Main()
